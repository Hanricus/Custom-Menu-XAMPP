12/4/2025

Cara guna:
paste je empat file ni dekat dalam htdocs folder XAMPP, make sure BACKUP Index.html yang lama

1. create.php: untuk create new project folder dalam htdocs

2. list.php : dia senaraikan semua project yang ada dalam htdocs

3. index.html : Custom menu ada link untuk pergi ke PhpAdmin, project, dengan dashboard.

4. style.css : untuk index.html


Macam mana nak linkkan /TUKAR NAMA/WARNA/ dan etc.

 Logo, tengok inde.html
 Warna, index.html tukar je dekat Style.css
 kalau warna untuk list project tukar je dalam tu.. sama jugak dengan create.php

P.S

Ni project aku buat waktu bosan mase kat rumah sewa kat uitm kelantan.. nak guna ambik je.. tapi credit la skit kat aku.. haha.. 