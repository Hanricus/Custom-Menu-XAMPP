<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $projectName = $_POST['project_name'];
    $dir = "C:/xampp/htdocs/" . $projectName;

    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);

        $indexFile = fopen($dir . "/index.php", "w");
        $content = <<<HTML
<?php
    echo "Jom start new projecttt!";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$projectName</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
            padding: 50px;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Welcome to the $projectName Project</h1>
    <p>Click the button below to open the project in Visual Studio Code</p>
    <a href="vscode://file/$dir" class="btn">Open in Visual Studio Code</a>
</body>
</html>
HTML;

        fwrite($indexFile, $content);
        fclose($indexFile);

        header("Location: list.php");
    } else {
        echo "Projek sudah wujud.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projek Baru</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            padding: 20px;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.05);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.3);
            max-width: 450px;
            width: 100%;
            text-align: center;
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 25px;
            text-shadow: 0 0 10px #00e6e6;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: none;
            margin-bottom: 20px;
            font-size: 1rem;
        }

        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            text-decoration: none;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1rem;
            transition: background-color 0.3s ease, transform 0.2s ease;
            cursor: pointer;
            box-shadow: 0 0 10px #00e6e6;
        }

        .btn-create {
            background-color: #00bcd4;
            color: white;
        }

        .btn-create:hover {
            background-color: #0097a7;
            transform: scale(1.05);
        }

        .btn-cancel {
            background-color: #ff4d4d;
            color: white;
        }

        .btn-cancel:hover {
            background-color: #cc0000;
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <div class="form-container">
        <h1>Buat Projek Baru</h1>
        <form action="create.php" method="POST">
            <input type="text" name="project_name" placeholder="Masukkan nama projek" required>
            <div class="btn-group">
                <input type="submit" value="Buat Projek" class="btn btn-create">
                <a href="list.php" class="btn btn-cancel">Batal</a>
            </div>
        </form>
    </div>

</body>
</html>
