<?php
$dir = "C:/xampp/htdocs";
$skip = array('..', '.', 'index.html', 'favicon.ico', 'bitnami1.css', 'styles.css', 'list.php', 'applications1.html');

// Tetapkan zon masa kepada Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

// Ambil semua folder dan modified time
$folders = [];
foreach (scandir($dir) as $item) {
    if (!in_array($item, $skip) && is_dir($dir . '/' . $item)) {
        $folders[$item] = filemtime($dir . '/' . $item); // waktu last modified
    }
}

// Susun ikut last modified, descending
arsort($folders);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <!-- Tukar nama kat sini -->
    <title>Senarai Projek Shakir</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
    color: #ffffff;
    font-family: 'Inter', sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.container {
    max-width: 960px;
    width: 100%;
    background-color: rgba(255, 255, 255, 0.05);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 0 30px rgba(0, 0, 0, 0.3);
    transition: box-shadow 0.3s ease;
}

.container:hover {
    box-shadow: 0 0 60px rgba(0, 0, 0, 0.4);
}

h1 {
    font-size: clamp(2rem, 4vw, 3rem);
    text-shadow: 0 0 12px #00e6e6, 0 0 24px #00e6e6;
    margin-bottom: 30px;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 30px;
}

.btn-group {
    display: flex;
    gap: 10px;
}

.new-btn, .home-btn {
    background-color: #00bcd4;
    color: white;
    padding: 12px 20px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 1rem;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 0 12px #00e6e6;
}

.new-btn:hover, .home-btn:hover {
    transform: translateY(-2px) scale(1.05);
    box-shadow: 0 0 25px #00e6e6;
}

.home-btn {
    background-color: #6c757d;
    box-shadow: 0 0 10px #aaa;
}

.home-btn:hover {
    background-color: #5a6268;
    box-shadow: 0 0 20px #bbb;
}

ul {
    list-style: none;
    margin-top: 10px;
    padding: 0;
}

li {
    background-color: #2a2a2a;
    margin-bottom: 16px;
    border-radius: 12px;
    overflow: hidden;
    transition: transform 0.3s ease, background-color 0.3s ease;
}

li:hover {
    background-color: #333;
    transform: scale(1.02);
}

li a {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px 22px;
    text-decoration: none;
    color: #00e6e6;
    font-size: 1.1rem;
    font-weight: 500;
    transition: background-color 0.3s ease, color 0.3s ease;
}

li a:hover {
    color: #ffffff;
    background-color: #3c3c3c;
}

.timestamp {
    font-size: 0.85rem;
    color: #aaa;
}
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>Senarai Projek</h1>
        <div class="btn-group">
            <a href="index.html" class="home-btn">← Balik ke Home</a>
            <a href="create.php" class="new-btn">+ Projek Baru</a>
        </div>
    </div>
    <ul>
        <?php foreach ($folders as $project => $time): ?>
            <li>
                <a href="http://localhost/<?= $project ?>">
                    <?= $project ?>
                    <span class="timestamp">(<?= date("d/m/Y h:i A", $time) ?>)</span>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

</body>
</html>
